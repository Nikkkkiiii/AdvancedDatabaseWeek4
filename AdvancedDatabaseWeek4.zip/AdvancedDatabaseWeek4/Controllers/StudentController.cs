﻿using AdvancedDatabaseWeek4.Service;
using Microsoft.AspNetCore.Mvc;

namespace AdvancedDatabaseWeek4.Controllers
{
    public class StudentController : Controller
    {
        private readonly IStudentService _studentService;

        public StudentController(IStudentService studentService)
        {
            _studentService = studentService;
        }
        [HttpPost, Route("AddStudent")]
        public async Task<IActionResult> AddStudent(Student student)
        {
            var addStudent = await _studentService.AddStudent(student);
            return Ok(addStudent);
        }

        public IActionResult Index()
        {
            return View();
        }
    }
}
